package ementas;

public class OvoLacto extends Alimento {

    public OvoLacto(double proteinas, double calorias, double peso) {
        super(proteinas, calorias, peso);
    }

}